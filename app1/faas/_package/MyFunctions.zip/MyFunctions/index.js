exports.nasaPlanetary = (req, res) => {
  var request = require('sync-request');

  const apiKey = '1iY4TLUenr5T79L9zi4yb1pZquCjtFVQoKn4ZjhN';
  const govPlanetaryApod = 'https://api.nasa.gov/planetary/apod';
  const request1 = request('GET', govPlanetaryApod
      + '?api_key='
      + apiKey);

  var jsonObj = JSON.parse(request1.body);
  res.send(jsonObj.date + ":" + jsonObj.explanation);
};
